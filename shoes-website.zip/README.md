# Shoe Store Website 👟

Simple static website with a shoe theme.

## Features
- Clean modern UI
- Easy to customize
- Ready for GitHub portfolio

## How to Run
Open `index.html` in your browser.

## Author
Created for GitHub project showcase.
